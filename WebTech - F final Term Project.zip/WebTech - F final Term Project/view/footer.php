<footer>

					<div class = "footer">
						<br>
						Copyrights &copy; 2023 All Rights Reserved by SHOHAN<br>

						 shohan.aiubcse@gmail.com <span class="middot">&middot;</span> <i class="icon-headphones"></i> 01968859654  <span class="middot"></span>

						 </div>
		</footer>

	

</body>
</html>