document.getElementById("test").innerHTML = "Hello world";
document.getElementById("test").style.color = "white";
document.getElementById("test").style.fontSize = "100px";
document.getElementById("test").style.backgroundColor = "red";