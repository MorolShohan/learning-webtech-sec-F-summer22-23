<!DOCTYPE html>
<html lang="en">
<head>
    <style> 
			fieldset{ 
			background-color: Gray ;
			}
			legend {
  			background-color: purple;
  			color: white;
  			padding: 5px 700px;
			}
			input {
  			margin: 10px;
			}
	</style>

    <title>Dashboard</title>
    
</head>
<body>
    
<div align ="center">

    <fieldset >

        <legend>
            <h3>Dashboard</h3>
        </legend> 

	<button><a href ="list_of_entry_product.php">Product inventory </a></button><br><br>
	<button><a href ="add_category.php">Add Category </a></button><br><br>
	<button><a href ="add_product.php">Add Product </a></button><br><br>
	<button><a href ="list_of_category.php">List of Category </a></button><br><br>
	<button><a href ="list_of_product.php">list of product </a></button><br><br>
	<button><a href ="list_of_users.php">List of Users </a></button><br><br>
	<button><a href ="llogin.php">Logout </a></button><br><br>
    
</fieldset>

    </div>
    
</body>
</html>