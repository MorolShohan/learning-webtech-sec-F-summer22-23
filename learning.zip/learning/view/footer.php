		<footer id="footer" class="dark">

					<div class="footer">
						<br>
						Copyrights &copy; 2023 All Rights Reserved by SHOHAN<br>

						<i></i> shohan.aiubcse@gmail.com <span class="middot">&middot;</span> <i class="icon-headphones"></i> 01968859654  <span class="middot"></span>

			
		</footer>
		</div>


		

	
	<div id="gotoTop" class="icon-angle-up"></div>

	

</body>
</html>