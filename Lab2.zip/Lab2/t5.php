<!DOCTYPE html>
<html>
<body>

<?php
$num;
echo "Odd numbers between 10 to 100 is : ";
for($num = 10; $num <= 100; $num++)
{
    if($num%2 == 1) 
    {echo "\n".$num;
        
    }
}
            
            
            
            
?>

</body>
</html>