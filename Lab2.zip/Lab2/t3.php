<!DOCTYPE html>
<html>
<body>

<?php
$num=6;
if($num %2==0)
{
echo "The number is even";
}

else

{
echo "The number is odd";
}

?>

</body>
</html>