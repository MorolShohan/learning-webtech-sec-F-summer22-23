<!DOCTYPE html>
<html>
<body>

<?php
$amount=500;
$vat=$amount*15*1/100;

echo "amount is :".$amount."<br>and vat is :".$vat;
?>

</body>
</html>