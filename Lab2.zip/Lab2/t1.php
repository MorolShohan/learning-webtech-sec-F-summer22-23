<!DOCTYPE html>
<html>
<body>

<?php
$length = 5;
$width = 4;
$z = $length*$width;
$v = 2 * ($length+$width);
echo "area of a rectangle is :".$z;
echo "<br>perimeter of a rectangle is :".$v;
?>

</body>
</html>