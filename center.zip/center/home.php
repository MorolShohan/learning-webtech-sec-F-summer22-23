<?php
header("Location: /center/View/login.php");
?>