<?php
    require 'Connect.php';

    function insert_manager($firstname, $lastname, $gender, $dob, $religion, $preaddress, $paraddress, $phone, $email, $username, $password) {
        $ezl = connect();

        $sql = "INSERT INTO manager(FirstName, LastName, Gender, PresentAddress, PermanentAddress, PhoneNo, Email, Username, Password) VALUES ('$firstname', '$lastname', '$gender', '$preaddress', '$paraddress', '$phone', '$email', '$username', '$password')";

        if($ezl->query($sql)) {
            header("location: /View/login.php");
            setcookie('msg', '<b> Registration Successful</b>', time() + 1, '/');
        }
        else {
            echo "Error: " . $sql . "<br>" . $ezl->error;
        }

        $ezl->close();
    }
    
    function insert_seller($name, $gender, $dob, $phone, $email, $username, $password) {
        $ezl = connect();

        $sql = "INSERT INTO seller(Name, Gender,  Email, Contact, Username, Password) VALUES ('$name', '$gender',  '$email', '$phone', '$username', '$password')";

        if($ezl->query($sql)) {
            header("location: /View/Seller.php");
            setcookie('msg', '<b> Registration Successful</b>', time() + 1, '/');
        }
        else {
            echo "Error: " . $sql . "<br>" . $ezl->error;
        }

        $ezl->close();
        header("location: /View/Seller.php");
    }
?>