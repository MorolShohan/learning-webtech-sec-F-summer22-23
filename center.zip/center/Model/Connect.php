<?php 
    function connect() {
        $server = "localhost";
        $db_user = "root";
        $db_pass = "";
        $dbname = "community_center";
        $ezl = new mysqli($server, $db_user, $db_pass, $dbname);

        if ($ezl->connect_error) {
            die("DB Con failed: " . $ezl->connect_error);
        }

        return $ezl;
    }
?>