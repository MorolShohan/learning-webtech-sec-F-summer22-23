function validregistration(reg) {
    let fnameErr = document.getElementById("fnameErr");
    let lnameErr = document.getElementById("lnameErr");
    let preErr = document.getElementById("preErr");
    let genderErr = document.getElementById("genderErr");
    let dobErr = document.getElementById("dobErr");
    let relErr = document.getElementById("relErr");
    let emailErr = document.getElementById("emailErr");
    let userErr = document.getElementById("userErr");
    let passErr = document.getElementById("passErr");
    let conpassErr = document.getElementById("conpassErr");

    fnameErr.innerHTML = "";
    lnameErr.innerHTML = "";
    dobErr.innerHTML = "";
    genderErr.innerHTML = "";
    relErr.innerHTML = "";
    preErr.innerHTML = "";
    emailErr.innerHTML = "";
    userErr.innerHTML = "";
    conpassErr.innerHTML = "";

    let firstname = reg.firstname.value;
    let lastname = reg.lastname.value;
    let gender = reg.gender.value;
    let dob = reg.dob.value;
    let religion = reg.religion.value;
    let preaddress = reg.preaddress.value;
    let email = reg.email.value;
    let username = reg.username.value;
    let password = reg.password.value;
    let conpassword = reg.conpassword.value;

    let isvalid = true;

    if (firstname == "") {
        fnameErr.innerHTML = "Check Name";
        isvalid = false;
    }
    if (lastname == "") {
        lnameErr.innerHTML = "Check Name";
        isvalid = false;
    }

    if (gender == "") {
        genderErr.innerHTML = "Selected Gender!";
        isvalid = false;
    }

    if (preaddress == "") {
        preErr.innerHTML = "Check Password!";
        isvalid = false;
    }
    var validRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;
    if (email == "") {
        emailErr.innerHTML = "Check Email";
        isvalid = false;
    } else if (!validRegex.test(email)) {
        emailErr.innerHTML = "Check EMAIL!";
        isvalid = false;
    }
    if (username == "") {
        userErr.innerHTML = "Check User Name!";
        isvalid = false;
    } 
    
    else if (username.length > 8) {
        userErr.innerHTML = "Check Name!";
        isvalid = false;
    }

    if (password == "") {
        passErr.innerHTML = "Check Password";
        isvalid = false;
    }

    if (conpassword == "") {
        conpassErr.innerHTML = "Confirm Password";
        isvalid = false;
    } 
    
    if (conpassword !== password) {
        passErr.innerHTML = "Not matched.";
        isvalid = false;
    }

    return isvalid;
}

function validteacher(reg) {
    let nameErr = document.getElementById("nameErr");
    let emailErr = document.getElementById("emailErr");
    let genderErr = document.getElementById("genderErr");
    let phoneErr = document.getElementById("phoneErr");
    let userErr = document.getElementById("userErr");
    let passErr = document.getElementById("passErr");
    let conpassErr = document.getElementById("conpassErr");

    nameErr.innerHTML = "";
    emailErr.innerHTML = "";
    genderErr.innerHTML = "";
    phoneErr.innerHTML = "";
    userErr.innerHTML = "";
    conpassErr.innerHTML = "";

    let name = reg.name.value;
    let gender = reg.gender.value;
    let email = reg.email.value;
    let phone = reg.phone.value;
    let username = reg.username.value;
    let password = reg.password.value;
    let confirmpassword = reg.conpassword.value;

    let isvalid = true;

    if(name == "") {
        nameErr.innerHTML = "Check Name!";
        isvalid = false;
    }

    if(gender == "") {
        genderErr.innerHTML = "Check Gender!";
        isvalid = false;
    }

    var validphone = /^[0-9]$/;
    if(phone == "") {
        phoneErr.innerHTML = "Check Number!";
        isvalid = false;
    }
    // else if(!validphone.test(phone)) {
    //     phoneErr.innerHTML = "❗Invalid contact number.";
    //     isvalid = false;
    // }
    var validemail = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;
    if(email == "") {
        emailErr.innerHTML = "Check Mail!";
        isvalid = false;
    }
    else if(!validemail.test(email)) {
        emailErr.innerHTML = "Mail";
        isvalid = false;
    }

    if(username == "") {
        userErr.innerHTML = "Check Name!";
        isvalid = false;
    }

    else if(username.length > 8) {
        userErr.innerHTML = "Unser Name Must be 8char long!";
        isvalid = false;
    }

    if(password == "") {
        passErr.innerHTML = "Check Password!";
        isvalid = false;
    }

    if(confirmpassword == "") {
        conpassErr.innerHTML = "Check Password!";
        isvalid = false;
    }

    if(confirmpassword !== password) {
        passErr.innerHTML = "No matched!";
        isvalid = false;
    }

    return isvalid;
}