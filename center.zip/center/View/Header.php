<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Header</title>
    </head>
    <body>
		<h1>Mordern Community Center</h1>
        <!--<a href="/center/dashboard.php"><<img src="/center/View/img/T_ENT_logo.png" alt="Mordern Community Center" height="150em" width="150em"></a>-->
    </body>
</html>