<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <fieldset style="width: 98%;">
        <?php include('../View/Header.php'); ?>
        <div style="float: right;">
            <a href="/center/View/ChangePass.php">Change Password</a> | <a href="/center/Controller/Logout.php">Logout</a>
        </div>
        <br>
        <div style="float: right;">
            <b>Admin Panel</b>
        </div>
    </fieldset>
    <br>
    <div style="width: 30%; float: left;">
        <ul>
            <a href="/center/View/Dashboard.php"><b> Home</b></a><br><br>
            <a href="/center/View/Admin.php"><b> Profile</b></a><br><br>
            <a href="/center/View/Seller.php"><b> Seller </b></a><br><br>
            <a href="/center/View/Manager.php"><b> Manager </b></a><br><br>
            <a href="/center/View/Buyer.php"><b> Buyer </b></a><br><br>
            <a href="/center/View/Community.php"><b>Community </b></a><br><br>
            <a href="/center/View/Query.php"><b> Help Session</b></a><br><br>
        </ul>
    </div>
</body>
</html>