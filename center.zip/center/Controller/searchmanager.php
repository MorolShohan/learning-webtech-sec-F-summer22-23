<?php
	require '../Model/ManagerDB.php';

	if(isset($_GET['manager'])) {
		$name = $_GET['manager'];
		$result = get($name);
	}

	if ($result->num_rows > 0) {
		echo "<table border='1' align='center'>";
		echo "<tr>";
        echo "<th>ID</th>";
        echo "<th>Name</th>";
        echo "<th>Email</th>";
        echo "<th>Phone No</th>";
        echo "<th>Username</th>";
        echo "<th>Action</th>";
		while ($data = $result->fetch_assoc()) {
            echo "</tr>";
	        echo "<tr>";
            echo "<td>" . $data['id'] . "</td>";
            echo "<td>" . $data['FirstName'] . " " . $data['LastName'] . "</td>";
            echo "<td>" . $data['email'] . "</td>";
            echo "<td>" . $data['phoneno'] . "</td>";
            echo "<td>" . $data['username'] . "</td>";
            echo "<td>" . "<a href='/center/Controller/DeleteActionManager.php?id=" . $data['id'] . "'>Delete</a></td>";
            echo "</tr>";
	    }
	    echo "</table>";
	}
	else {
		echo "No record(s) found";
	}
?>
