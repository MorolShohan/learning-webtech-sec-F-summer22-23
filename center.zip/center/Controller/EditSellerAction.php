<?php 
    session_start();

    require '../Model/SellerDB.php';
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Form submit</title>
    </head>
    <body>
        <?php 
            $id = $name = $gender = $phone = $email = $username = "";
            
             $emailErr = $usernameErr = $passwordErr  = "";

            $isValid = true;
            $isChecked = $isEmpty = false;

            if ($_SERVER['REQUEST_METHOD'] == "POST") {
                $isChecked = true;
                function test($data) {
                    $data = trim($data);
                    $data = stripslashes($data);
                    $data = htmlspecialchars($data);
                    return $data;
                }

                $id = test($_POST["id"]);
                $name = test($_POST["name"]);
                $phone = test($_POST["phone"]);
                $email = test($_POST["email"]);
                $username = test($_POST["username"]);
                $year = date("Y") - intval($dob);

                if(empty($name)) {
                    $isValid = false;
                    $isEmpty = true;
                }

                if(empty($_POST["gender"])) {
                    $isValid = false;
                    $isEmpty = true;
                }
                else
                    $gender = $_POST["gender"];
                    
                    
                if(empty($email)) {
                    $isValid = false;
                    $isEmpty = true;
                }

                else if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                    $isValid = false;
                    $emailErr = "<br>Check email format";
                }

                if(empty($username)) {
                    $isValid = false;
                    $isEmpty = true;
                }

                if(strlen($username) > 8) {
                    $isValid = false;
                    $usernameErr = "<br>Username should be 8 char long";
                }

                if($isValid and $isChecked){
                    edit($id, $name, $gender, $phone, $email, $username);
                }

                else if ($isEmpty) {
                    setcookie('msg', '<b>Check Interted Data</b><br>', time() + 1, '/');
                    header("location: /center/View/EditSeller.php?id=$id");
                }
    
                else {
                    if($emailErr != NULL)
                        setcookie('email', $emailErr, time() + 1, '/');
                    if($usernameErr != NULL)
                        setcookie('user', $usernameErr, time() + 1, '/');
                    header("location: /center/View/EditSeller.php?id=$id");
                }
            }
        ?>
    </body>
</html>