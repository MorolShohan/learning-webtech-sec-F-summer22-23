<?php 
    require '../Model/RegistrationDB.php';
    session_start();    
    $firstname = $lastname = $gender = $dob = $religion = $preaddress = $paraddress = $phone = $email = $website = $username = $password = $conpassword = "";
    
    $dobErr = $emailErr = $usernameErr = $passwordErr = $religionErr = "";

    $isValid = true;
    $isChecked = $isEmpty = false;

    if ($_SERVER['REQUEST_METHOD'] == "POST")
     {
        $isChecked = true;
        function test($data) {
            $data = trim($data);
            $data = stripslashes($data);
            $data = htmlspecialchars($data);
            return $data;
        }
      

        $firstname = test($_POST["firstname"]);
        $lastname = test($_POST["lastname"]);
        $preaddress = test($_POST["preaddress"]);
        $paraddress = test($_POST["paraddress"]);
        $phone = test($_POST["phone"]);
        $email = test($_POST["email"]);
        $username = test($_POST["username"]);
        $password = test($_POST["password"]);
        $conpassword = test($_POST["conpassword"]);
        #$year = date("Y") - intval($dob);

        if(empty($firstname)) {
            $isValid = false;
            $isEmpty = true;
        }

        if(empty($lastname)) {
            $isValid = false;
            $isEmpty = true;
        }

        if(empty($_POST["gender"])) {
            $isValid = false;
            $isEmpty = true;
        }
        else
            $gender = $_POST["gender"];

        if(empty($dob)) {
            $isValid = false;
        }

        if(empty($preaddress)) {
            $isValid = false;
            $isEmpty = true;
        }

        if(empty($email)) {
            $isValid = false;
            $isEmpty = true;
        }

        else if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $isValid = false;
            $emailErr = "<br>Invalid email format";
        }

        if(empty($username)) {
            $isValid = false;
            $isEmpty = true;
        }

        if(strlen($username) > 8) {
            $isValid = false;
            $usernameErr = "<br>Username up to 8 characters long";
        }

        if(empty($password)) {
            $isValid = false;
            $isEmpty = true;
        }

        else if(strlen($password) < 8) {
            $isValid = false;
            $passwordErr = "<br>Password must be at least 8 characters long";
        }

        if(empty($conpassword)) {
            $isValid = false;
            $isEmpty = true;
        }

        if($password != $conpassword) {
            $isValid = false;
            $passwordErr = "<br>Password not matched";
        }
      }
      if ($isValid === true) {

        $_SESSION['name_error_msg'] = "";
        $_SESSION['email_error_msg'] = "";
        $_SESSION['gender_error_msg'] = "" ;
        $_SESSION['password_error_msg'] = "" ;
        $_SESSION['cpassword_error_msg'] = "" ;
        $_SESSION['phone_error_msg'] = "" ;
        

        $sql = "INSERT INTO `buyer`(`id`, `name`, `gender`, `email`, `contact`, `username`, `password`) VALUES (NULL, '$name', '$gender', '$email', '$contact', '$username', '$password')";
        
        $result = mysqli_query($conn, $sql);

        if($result)
        {
            header("Location:../View/login.php");
        }

        else
        {
            echo "Something went wrong" . mysqli_error($conn);
        }

        
    }
    
    else
    {
        header('Location:../view/registration.php');
    }
    mysqli_close($conn);

function sanitize($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}
      
?>