<?php
	require '../Model/ApartmentDB.php';

	if(isset($_GET['community'])) {
		$name = $_GET['community'];
		$result = get($name);
	}

	if ($result->num_rows > 0) {
		echo "<table border='1' align='center'>";
		echo "<tr>";
        echo "<th>ID</th>";
        echo "<th>Price</th>";
        echo "<th>Location</th>";
        echo "<th>Details</th>";
        echo "<th>Action</th>";
		while ($data = $result->fetch_assoc()) {
            echo "</tr>";
	        echo "<tr>";
            echo "<td>" . $data['id'] . "</td>";
            echo "<td>" . $data['price'] . "</td>";
            echo "<td>" . $data['location'] . "</td>";
            echo "<td>" . $data['details'] . "</td>";

            echo "<td><a href='/center/Controller/DeleteActionApartment.php?id=" . $data['id'] ."'>Delete</a></td>";
            echo "</tr>";
	    }
	    echo "</table>";
	}
	else {
		echo "No record(s) found";
	}
?>